﻿using BookDatabase.bookClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookDatabase
{
    public partial class Books : Form
    {
        public Books()
        {
            InitializeComponent();
        }
        bookClass b = new bookClass();

        private void btnAdd_Click(object sender, EventArgs e)
        {
            b.Title = txtboxTitle.Text;
            b.Author = txtboxAuthor.Text;
            b.ReleaseDate = txtboxDate.Text;
            b.Publisher = txtboxPublisher.Text;
            b.Borrow = cmbBorrow.Text;

            bool success = b.Insert(b);
            if(success==true)
            {
                MessageBox.Show("Sikeresen hozzáadva!");
                Clear();
            }
            else
            {
                MessageBox.Show("Hozzáadás sikertelen!");
            }
            DataTable dt = b.Select();
            dgvBookList.DataSource = dt;
        }

        private void Books_Load(object sender, EventArgs e)
        {
            DataTable dt = b.Select();
            dgvBookList.DataSource = dt;
        }

        public void Clear()
        {
            txtboxTitle.Text = "";
            txtboxAuthor.Text = "";
            txtboxDate.Text = "";
            txtboxPublisher.Text = "";
            cmbBorrow.Text = "";
            txtboxBookID.Text = "";
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            b.BookID = int.Parse(txtboxBookID.Text);
            b.Title = txtboxTitle.Text;
            b.Author = txtboxAuthor.Text;
            b.ReleaseDate = txtboxDate.Text;
            b.Publisher = txtboxPublisher.Text;
            b.Borrow = cmbBorrow.Text;

            bool success = b.Update(b);
            if(success == true)
            {
                MessageBox.Show("Sikeresen frissítve!");
                DataTable dt = b.Select();
                dgvBookList.DataSource = dt;
                Clear();
            }
            else
            {
                MessageBox.Show("Sikertelen!");
            }

        }

        private void dgvBookList_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int rowIndex = e.RowIndex;
            txtboxBookID.Text = dgvBookList.Rows[rowIndex].Cells[0].Value.ToString();
            txtboxAuthor.Text = dgvBookList.Rows[rowIndex].Cells[1].Value.ToString();
            txtboxDate.Text = dgvBookList.Rows[rowIndex].Cells[2].Value.ToString();
            txtboxPublisher.Text = dgvBookList.Rows[rowIndex].Cells[3].Value.ToString();
            cmbBorrow.Text = dgvBookList.Rows[rowIndex].Cells[4].Value.ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            b.BookID = Convert.ToInt32(txtboxBookID.Text);
            bool success = b.Delete(b);
            if (success == true)
            {
                MessageBox.Show("Törölve!");
                DataTable dt = b.Select();
                dgvBookList.DataSource = dt;
                Clear();
            }
            else
            {
                MessageBox.Show("Hiba! Törlés sikertelen!");
            }

        }
        static string myconnstr = ConfigurationManager.ConnectionStrings["connstrng"].ConnectionString;

        private void txtboxSearch_TextChanged(object sender, EventArgs e)
        {
            string keyword = txtboxSearch.Text;
            SqlConnection conn = new SqlConnection(myconnstr);
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM tbl_books WHERE Title LIKE '%" + keyword + "%' OR Author LIKE '%" + keyword + "%' OR ReleaseDate LIKE '%" + keyword + "%' OR Publisher LIKE '%" + keyword + "%'", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvBookList.DataSource = dt;

        }
    }
}
