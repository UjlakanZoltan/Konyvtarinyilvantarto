﻿namespace BookDatabase
{
    partial class Books
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBookID = new System.Windows.Forms.Label();
            this.txtboxBookID = new System.Windows.Forms.TextBox();
            this.txtboxTitle = new System.Windows.Forms.TextBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.txtboxAuthor = new System.Windows.Forms.TextBox();
            this.lblAuthor = new System.Windows.Forms.Label();
            this.txtboxDate = new System.Windows.Forms.TextBox();
            this.lblDate = new System.Windows.Forms.Label();
            this.txtboxPublisher = new System.Windows.Forms.TextBox();
            this.lblPublisher = new System.Windows.Forms.Label();
            this.lblBorrow = new System.Windows.Forms.Label();
            this.cmbBorrow = new System.Windows.Forms.ComboBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.dgvBookList = new System.Windows.Forms.DataGridView();
            this.lblSearch = new System.Windows.Forms.Label();
            this.txtboxSearch = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBookList)).BeginInit();
            this.SuspendLayout();
            // 
            // lblBookID
            // 
            this.lblBookID.AutoSize = true;
            this.lblBookID.Location = new System.Drawing.Point(12, 9);
            this.lblBookID.Name = "lblBookID";
            this.lblBookID.Size = new System.Drawing.Size(68, 17);
            this.lblBookID.TabIndex = 0;
            this.lblBookID.Text = "Könyv ID:";
            // 
            // txtboxBookID
            // 
            this.txtboxBookID.Location = new System.Drawing.Point(85, 6);
            this.txtboxBookID.Name = "txtboxBookID";
            this.txtboxBookID.ReadOnly = true;
            this.txtboxBookID.Size = new System.Drawing.Size(167, 22);
            this.txtboxBookID.TabIndex = 1;
            // 
            // txtboxTitle
            // 
            this.txtboxTitle.Location = new System.Drawing.Point(85, 34);
            this.txtboxTitle.Name = "txtboxTitle";
            this.txtboxTitle.Size = new System.Drawing.Size(167, 22);
            this.txtboxTitle.TabIndex = 3;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(12, 37);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(35, 17);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "Cím:";
            // 
            // txtboxAuthor
            // 
            this.txtboxAuthor.Location = new System.Drawing.Point(85, 62);
            this.txtboxAuthor.Name = "txtboxAuthor";
            this.txtboxAuthor.Size = new System.Drawing.Size(167, 22);
            this.txtboxAuthor.TabIndex = 5;
            // 
            // lblAuthor
            // 
            this.lblAuthor.AutoSize = true;
            this.lblAuthor.Location = new System.Drawing.Point(12, 65);
            this.lblAuthor.Name = "lblAuthor";
            this.lblAuthor.Size = new System.Drawing.Size(56, 17);
            this.lblAuthor.TabIndex = 4;
            this.lblAuthor.Text = "Szerző:";
            // 
            // txtboxDate
            // 
            this.txtboxDate.Location = new System.Drawing.Point(100, 90);
            this.txtboxDate.MaxLength = 4;
            this.txtboxDate.Name = "txtboxDate";
            this.txtboxDate.Size = new System.Drawing.Size(152, 22);
            this.txtboxDate.TabIndex = 7;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(12, 93);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(82, 17);
            this.lblDate.TabIndex = 6;
            this.lblDate.Text = "Kiadás éve:";
            // 
            // txtboxPublisher
            // 
            this.txtboxPublisher.Location = new System.Drawing.Point(85, 118);
            this.txtboxPublisher.Name = "txtboxPublisher";
            this.txtboxPublisher.Size = new System.Drawing.Size(167, 22);
            this.txtboxPublisher.TabIndex = 9;
            // 
            // lblPublisher
            // 
            this.lblPublisher.AutoSize = true;
            this.lblPublisher.Location = new System.Drawing.Point(12, 121);
            this.lblPublisher.Name = "lblPublisher";
            this.lblPublisher.Size = new System.Drawing.Size(48, 17);
            this.lblPublisher.TabIndex = 8;
            this.lblPublisher.Text = "Kiadó:";
            // 
            // lblBorrow
            // 
            this.lblBorrow.AutoSize = true;
            this.lblBorrow.Location = new System.Drawing.Point(12, 149);
            this.lblBorrow.Name = "lblBorrow";
            this.lblBorrow.Size = new System.Drawing.Size(84, 17);
            this.lblBorrow.TabIndex = 10;
            this.lblBorrow.Text = "Kölcsönzés:";
            // 
            // cmbBorrow
            // 
            this.cmbBorrow.FormattingEnabled = true;
            this.cmbBorrow.Items.AddRange(new object[] {
            "Igen",
            "Nem"});
            this.cmbBorrow.Location = new System.Drawing.Point(96, 147);
            this.cmbBorrow.Name = "cmbBorrow";
            this.cmbBorrow.Size = new System.Drawing.Size(72, 24);
            this.cmbBorrow.TabIndex = 11;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.LimeGreen;
            this.btnAdd.Location = new System.Drawing.Point(15, 186);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 34);
            this.btnAdd.TabIndex = 12;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdate.Location = new System.Drawing.Point(96, 186);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 34);
            this.btnUpdate.TabIndex = 13;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Yellow;
            this.btnClear.Location = new System.Drawing.Point(177, 146);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 34);
            this.btnClear.TabIndex = 14;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Red;
            this.btnDelete.Location = new System.Drawing.Point(177, 186);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 34);
            this.btnDelete.TabIndex = 15;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // dgvBookList
            // 
            this.dgvBookList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBookList.Location = new System.Drawing.Point(285, 6);
            this.dgvBookList.Name = "dgvBookList";
            this.dgvBookList.RowHeadersWidth = 51;
            this.dgvBookList.RowTemplate.Height = 24;
            this.dgvBookList.Size = new System.Drawing.Size(656, 471);
            this.dgvBookList.TabIndex = 16;
            this.dgvBookList.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvBookList_RowHeaderMouseClick);
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Location = new System.Drawing.Point(12, 252);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(64, 17);
            this.lblSearch.TabIndex = 17;
            this.lblSearch.Text = "Keresés:";
            // 
            // txtboxSearch
            // 
            this.txtboxSearch.Location = new System.Drawing.Point(75, 249);
            this.txtboxSearch.Name = "txtboxSearch";
            this.txtboxSearch.Size = new System.Drawing.Size(177, 22);
            this.txtboxSearch.TabIndex = 18;
            this.txtboxSearch.TextChanged += new System.EventHandler(this.txtboxSearch_TextChanged);
            // 
            // Books
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(953, 489);
            this.Controls.Add(this.txtboxSearch);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.dgvBookList);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.cmbBorrow);
            this.Controls.Add(this.lblBorrow);
            this.Controls.Add(this.txtboxPublisher);
            this.Controls.Add(this.lblPublisher);
            this.Controls.Add(this.txtboxDate);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.txtboxAuthor);
            this.Controls.Add(this.lblAuthor);
            this.Controls.Add(this.txtboxTitle);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.txtboxBookID);
            this.Controls.Add(this.lblBookID);
            this.Name = "Books";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "KönyvtáriNyilvántartó";
            this.Load += new System.EventHandler(this.Books_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBookList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBookID;
        private System.Windows.Forms.TextBox txtboxBookID;
        private System.Windows.Forms.TextBox txtboxTitle;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.TextBox txtboxAuthor;
        private System.Windows.Forms.Label lblAuthor;
        private System.Windows.Forms.TextBox txtboxDate;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.TextBox txtboxPublisher;
        private System.Windows.Forms.Label lblPublisher;
        private System.Windows.Forms.Label lblBorrow;
        private System.Windows.Forms.ComboBox cmbBorrow;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.DataGridView dgvBookList;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.TextBox txtboxSearch;
    }
}

