﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookDatabase.bookClasses
{
    class bookClass
    {
        public int BookID { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string ReleaseDate { get; set; }
        public string Publisher { get; set; }
        public string Borrow { get; set; }

        static string myconnstrng = ConfigurationManager.ConnectionStrings["connstrng"].ConnectionString;

        public DataTable Select()
        {
            SqlConnection conn = new SqlConnection(myconnstrng);
            DataTable dt = new DataTable();
            try
            {
                string sql = "SELECT * FROM tbl_books";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                conn.Open();
                adapter.Fill(dt);

            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return dt;
        }

        public bool Insert (bookClass b)
        {
            bool isSuccess = false;
            SqlConnection conn = new SqlConnection(myconnstrng);
            try
            {
                string sql = "INSERT INTO tbl_books (Title, Author, ReleaseDate, Publisher, Borrow) VALUES (@Title, @Author, @ReleaseDate, @Publisher, @Borrow)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Title", b.Title);
                cmd.Parameters.AddWithValue("@Author", b.Author);
                cmd.Parameters.AddWithValue("@ReleaseDate", b.ReleaseDate);
                cmd.Parameters.AddWithValue("@Publisher", b.Publisher);
                cmd.Parameters.AddWithValue("@Borrow", b.Borrow);

                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0) 
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch(Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return isSuccess;
        }

        public bool Update(bookClass b)
        {
            bool isSuccess = false;
            SqlConnection conn = new SqlConnection(myconnstrng);
            try
            {
                string sql = "UPDATE tbl_books SET Title=@Title, Author=@Author, ReleaseDate=@ReleaseDate, Publisher=@Publisher, Borrow=@Borrow WHERE BookID=@BookID";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Title", b.Title);
                cmd.Parameters.AddWithValue("@Author", b.Author);
                cmd.Parameters.AddWithValue("@ReleaseDate", b.ReleaseDate);
                cmd.Parameters.AddWithValue("@Publisher", b.Publisher);
                cmd.Parameters.AddWithValue("@Borrow", b.Borrow);
                cmd.Parameters.AddWithValue("@BookID", b.BookID);
                
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                if(rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch(Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return isSuccess;
        }

        public bool Delete(bookClass b)
        {
            bool isSuccess = false;
            SqlConnection conn = new SqlConnection(myconnstrng);
            try
            {
                string sql = "DELETE FROM tbl_books WHERE BookID=@BookID";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@BookID", b.BookID);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch(Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return isSuccess;
        }

    }
}
